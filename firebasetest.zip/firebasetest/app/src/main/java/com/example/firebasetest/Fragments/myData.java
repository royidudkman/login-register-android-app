package com.example.firebasetest.Fragments;

import com.example.firebasetest.R;

public class myData {

    static String[] nameArray = {"בורקס גבינה גדול","בייגל","בקלאווה ","כנאפה גבינה","מנקושה"
            ,"סמבוסק בולגרית","פיצה אישית","פיתה זעתר","בורקס תפוח'א"};

    static Integer[] drawableArray = {R.drawable.image1, R.drawable.image2, R.drawable.image3,
            R.drawable.image4, R.drawable.image5, R.drawable.image6, R.drawable.image7, R.drawable.image8, R.drawable.image9};

    static Integer[] id_ = {0, 1, 2, 3, 4, 5, 6, 7, 8};

}
