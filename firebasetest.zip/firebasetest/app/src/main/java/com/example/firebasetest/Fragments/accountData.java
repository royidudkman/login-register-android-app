package com.example.firebasetest.Fragments;

import com.example.firebasetest.R;

public class accountData {
    static String[] nameArray = {"1","2","3","4","5"};

    static Integer[] drawableArray = {R.drawable.image1, R.drawable.image2, R.drawable.image3,
            R.drawable.image4, R.drawable.image5};

    static Integer[] id_ = {0, 1, 2, 3, 4};
}
