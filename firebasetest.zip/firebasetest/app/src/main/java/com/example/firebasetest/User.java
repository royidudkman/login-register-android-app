package com.example.firebasetest;

import com.example.firebasetest.RecycleView.DataModel;

import java.util.ArrayList;

public class User {

    public String uId;

    public String name;
    public String email;
    public String phone;
    public ArrayList<DataModel> dataSet;


    public User(){

    }
    public User(String uId, String name, String email, String phone) {
        this.uId = uId;
        this.email = email;
        this.phone = phone;
        this.name = name;
    }
    public User(String uId, String email, String phone, ArrayList<DataModel> dataSet) {
        this.uId = uId;
        this.email = email;
        this.phone = phone;
        this.dataSet = dataSet;
    }


    public String getName()
    {
        return name;
    }
//    @Override
//    public String toString() {
//        return "Data{" +
//                "email='" + email + '\'' +
//                ", name='" + name + '\'' +
//                ", password='" + password + '\'' +
//                ", phone='" + phone + '\'' +
//                '}';
//    }


}
