package com.example.firebasetest.Fragments;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.fragment.NavHostFragment;

import com.example.firebasetest.Data;
import com.example.firebasetest.R;
import com.example.firebasetest.User;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class RegisterFragment extends Fragment {

    private FirebaseAuth mAuth;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.register_layout, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mAuth = FirebaseAuth.getInstance();

        view.findViewById(R.id.registerBtn).setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                RegisterFunc();

            }
        });
    }

    private void showMessage(String message) {
        TextView messageTextView = getView().findViewById(R.id.messageTextView);
        messageTextView.setText(message);
        messageTextView.setVisibility(View.VISIBLE);
    }

    public void RegisterFunc() {

        String email = ((EditText) getView().findViewById(R.id.textEmail)).getText().toString().trim();
        String password = ((EditText) getView().findViewById(R.id.textPassword)).getText().toString().trim();
        String phone = ((EditText) getView().findViewById(R.id.textPhone)).getText().toString().trim();
        String name = ((EditText) getView().findViewById(R.id.textName)).getText().toString().trim();

        NavController navController = NavHostFragment.findNavController(this);

        if (TextUtils.isEmpty(email) || TextUtils.isEmpty(password) || TextUtils.isEmpty(phone) || TextUtils.isEmpty(name)) {
            showMessage("Please enter all fields");
            return;
        }

        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(requireActivity(), new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            Toast.makeText(requireContext(), "Registered Successfuly", Toast.LENGTH_LONG).show();
                            FirebaseUser user = mAuth.getCurrentUser();
                            writeUserDataToDatabase(user.getUid(), name, email,phone);
                            navController.navigate((R.id.action_registerFragment2_to_loginFragment));

                        } else {
                            // If sign in fails, display a message to the user.
                            showMessage("Registration failed. Please try again later.");


                        }
                    }
                });
    }

    private void writeUserDataToDatabase(String userId, String name, String email, String phone) {

        User newUser = new User(userId, name, email, phone);
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference usersRef = database.getReference("users").child(userId);

        //usersRef.child(userId).setValue(newUser);
        usersRef.setValue(newUser);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
    }
}
