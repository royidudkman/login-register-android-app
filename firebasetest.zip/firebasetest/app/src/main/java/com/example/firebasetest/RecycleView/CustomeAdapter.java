package com.example.firebasetest.RecycleView;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.example.firebasetest.R;

import java.util.ArrayList;


public class CustomeAdapter extends RecyclerView.Adapter<CustomeAdapter.MyViewHolder> {

    private ArrayList<DataModel> dataSet;
    private LayoutInflater inflater;
    private OnItemClickListener mListener;

    public interface OnItemClickListener {
        void onItemClick(DataModel item);
    }

    public CustomeAdapter(Context context, ArrayList<DataModel> dataSet, OnItemClickListener listener) {
        this.dataSet = dataSet;
        this.inflater = LayoutInflater.from(context);
        this.mListener = listener;
    }


    public static class MyViewHolder extends RecyclerView.ViewHolder {

        TextView textViewName;
        ImageView imageView;
        Button addToCartBtn;

        public MyViewHolder(@NonNull View itemView, ArrayList<DataModel> dataSet, OnItemClickListener listener) {
            super(itemView);
            textViewName = itemView.findViewById(R.id.textView);
            imageView = itemView.findViewById(R.id.imageView);
            addToCartBtn = itemView.findViewById(R.id.addToCartBtn);

            addToCartBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int position = getAdapterPosition();
                    if (position != RecyclerView.NO_POSITION && listener != null) {
                        listener.onItemClick(dataSet.get(position));
                    }
                }
            });
        }

    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.shop_cardrow, parent, false);
        MyViewHolder myViewHolder = new MyViewHolder(view, dataSet, mListener);
        return myViewHolder;
    }



    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        holder.textViewName.setText(dataSet.get(position).getName());
        holder.imageView.setImageResource(dataSet.get(position).getImage());

        holder.addToCartBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int adapterPosition = holder.getAdapterPosition();
                if (adapterPosition != RecyclerView.NO_POSITION && mListener != null) {
                    mListener.onItemClick(dataSet.get(adapterPosition));
                }
            }
        });
    }



    @Override
    public int getItemCount() {
        return dataSet.size();
    }
}