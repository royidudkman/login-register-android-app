package com.example.firebasetest.Fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.fragment.NavHostFragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.firebasetest.Data;
import com.example.firebasetest.MainActivity;
import com.example.firebasetest.R;
import com.example.firebasetest.RecycleView.CustomeAdapter;
import com.example.firebasetest.RecycleView.DataModel;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class HomeScreenFragment extends Fragment {

    private ArrayList<DataModel> dataSet;
    private RecyclerView recyclerView;
    private LinearLayoutManager layoutManager;
    private CustomeAdapter adapter;
    private FirebaseAuth mAuth;
    private TextView titleText;
    private String userName;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.homescreen_layout, container, false);

        recyclerView = view.findViewById(R.id.resView);
        dataSet = new ArrayList<>();
        layoutManager = new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(layoutManager);
        titleText = view.findViewById(R.id.titleText);

        mAuth = FirebaseAuth.getInstance();
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser != null) {
            String userId = currentUser.getUid();
            DatabaseReference userRef = FirebaseDatabase.getInstance().getReference("users").child(userId);
            userRef.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    if (dataSnapshot.exists()) {
                        // Assuming there's a field called "name" in your user data model
                        userName = dataSnapshot.child("name").getValue(String.class);
                        if (userName != null) {
                            titleText.setText("Welcome, " + userName);
                        }
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    // Handle onCancelled if needed
                }
            });
        }



        for ( int i =0 ; i < myData.nameArray.length ; i++){
            dataSet.add(new DataModel(
                    myData.nameArray[i],
                    myData.drawableArray[i],
                    myData.id_[i]
            ));
        }

        adapter = new CustomeAdapter(getContext(), dataSet, new CustomeAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(DataModel item) {
                Toast.makeText(getContext(), "Added to cart", Toast.LENGTH_SHORT).show();
                WriteDataFunc(item);
            }
        });
        recyclerView.setAdapter(adapter);

        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        // Any additional setup after the view has been created
        mAuth = FirebaseAuth.getInstance();

        NavController navController = NavHostFragment.findNavController(this);

        view.findViewById(R.id.goToCartBtn).setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Bundle bundle = new Bundle();
                bundle.putString("name", userName);
                navController.navigate(R.id.action_homeScreenFragment2_to_cartScreenFragment,bundle);
            }
        });
    }

    public void WriteDataFunc(DataModel dataModel) {

        String uId = mAuth.getCurrentUser().getUid();

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference userRef = database.getReference("users");

        String itemName = dataModel.getName();
        DatabaseReference specificItemRef = userRef.child(uId).child("items").child(itemName);

        specificItemRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    // Item already exists, update its details
                    DataModel existingItem = dataSnapshot.getValue(DataModel.class);
                    int newAmount = existingItem.getAmount() + 1; // Update the amount
                    existingItem.setAmount(newAmount);

                    // Update the item in the database
                    specificItemRef.setValue(existingItem);
                } else {
                    // Item doesn't exist, create a new one
                    specificItemRef.setValue(dataModel);
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Handle error
            }
        });

    }
}


