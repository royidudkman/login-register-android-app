package com.example.firebasetest.RecycleView;

import android.content.Context;

public class DataModel {

    private String name;
    private int image; // Integer
    private int id_;

    private int amount = 1;

    public DataModel() {
        // Default constructor required by Firebase
    }
    public DataModel(String name, int image, int id_) {
        this.name = name;
        this.image = image;
        this.id_ = id_;
    }

    public void setAmount(int amount)
    {
        this.amount = amount;
    }

    public void increaseAmount()
    {
        amount++;
    }
    public int getAmount()
    {
        return amount;
    }
    public void setName(String name) {
        this.name = name;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public String getName() {
        return name;
    }

    public int getId_() {
        return id_;
    }

    public int getImage() {
        return image;
    }

}









