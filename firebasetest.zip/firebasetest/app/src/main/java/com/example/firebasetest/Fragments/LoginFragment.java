package com.example.firebasetest.Fragments;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.fragment.NavHostFragment;

import com.example.firebasetest.Data;
import com.example.firebasetest.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class LoginFragment extends Fragment {

    private FirebaseAuth mAuth;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.login_layout, container, false);

    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mAuth = FirebaseAuth.getInstance();

        NavController navController = NavHostFragment.findNavController(this);

        view.findViewById(R.id.registerBtn).setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                navController.navigate(R.id.action_loginFragment_to_registerFragment2);

            }
        });

        view.findViewById(R.id.loginBtn).setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                LoginFunc();
            }
        });
    }

    private void showMessage(String message) {
        TextView messageTextView = getView().findViewById(R.id.messageTextView);
        messageTextView.setText(message);
        messageTextView.setVisibility(View.VISIBLE);
    }
    public void LoginFunc() {

        String email = ((EditText) getView().findViewById(R.id.textEmail)).getText().toString().trim();
        String password = ((EditText) getView().findViewById(R.id.textPassword)).getText().toString().trim();

        if (TextUtils.isEmpty(email) || TextUtils.isEmpty(password)) {
            showMessage("Please enter both email and password");
            return;
        }

        mAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(requireActivity(), new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            Toast.makeText(requireContext(), "Successful Login", Toast.LENGTH_LONG).show();
                            FirebaseUser user = mAuth.getCurrentUser();
                            if(user != null){
                                NavController navController = NavHostFragment.findNavController(LoginFragment.this);
                                navController.navigate(R.id.action_loginFragment_to_homeScreenFragment2);
                            }
                            else{
                                showMessage("User does not exist");
                            }

                        } else {
                            // If sign in fails, display a message to the user.
                            showMessage("Login failed. Please check your credentials.");

                        }
                    }
                });
    }





    @Override
    public void onDestroyView() {
        super.onDestroyView();
    }


}
