package com.example.firebasetest.Fragments;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.fragment.NavHostFragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.firebasetest.R;
import com.example.firebasetest.RecycleView.CartCustomeAdapter;
import com.example.firebasetest.RecycleView.CustomeAdapter;
import com.example.firebasetest.RecycleView.DataModel;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;


public class CartScreenFragment extends Fragment {

    private ArrayList<DataModel> dataSet;
    private RecyclerView recyclerView;
    private LinearLayoutManager layoutManager;
    private CartCustomeAdapter adapter;
    private FirebaseAuth mAuth;
    private DatabaseReference userRef;
    private TextView titleText;
    private String userName;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_cart_screen, container, false);

        recyclerView = view.findViewById(R.id.resView);
        dataSet = new ArrayList<>();
        layoutManager = new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(layoutManager);
        titleText = view.findViewById(R.id.titleText);

        if (getArguments() != null) {
            userName = getArguments().getString("name");
        }
        titleText.setText(userName + "'s cart:");

        mAuth = FirebaseAuth.getInstance();
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if(currentUser != null){
            String uId = currentUser.getUid();
            FirebaseDatabase database = FirebaseDatabase.getInstance();
            userRef = database.getReference("users").child(uId).child("items");

            userRef.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    // Clear the dataSet to avoid duplicates
                    dataSet.clear();

                    // Iterate through the dataSnapshot and add items to dataSet
                    for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                        DataModel item = snapshot.getValue(DataModel.class);
                        if (item != null) {
                            dataSet.add(item);
                        }
                    }

                    // Update the adapter with the new data
                    adapter.notifyDataSetChanged();
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    // Handle onCancelled if needed
                }
            });

        }

        adapter = new CartCustomeAdapter(getContext(), dataSet, new CartCustomeAdapter.OnItemClickListener(){

            @Override
            public void onUpButtonClick(DataModel item) {
                WriteDataFunc(item,1);
            }

            @Override
            public void onDownButtonClick(DataModel item) {
                WriteDataFunc(item, -1);
            }
        });

        recyclerView.setAdapter(adapter);

        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
    }

    public void WriteDataFunc(DataModel dataModel, int changeAmount) {

        String uId = mAuth.getCurrentUser().getUid();

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference userRef = database.getReference("users");

        String itemName = dataModel.getName();
        DatabaseReference specificItemRef = userRef.child(uId).child("items").child(itemName);

        specificItemRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    // Item already exists, update its details
                    DataModel existingItem = dataSnapshot.getValue(DataModel.class);
                    int newAmount = existingItem.getAmount() + changeAmount; // Update the amount
                    existingItem.setAmount(newAmount);

                    if(newAmount <= 0) {
                        specificItemRef.removeValue();
                        dataSet.remove(dataModel);
                    }
                    else{
                        specificItemRef.setValue(existingItem);
                    }
                    // Update the item in the database
                } else {
                    // Item doesn't exist, create a new one
                    specificItemRef.setValue(dataModel);
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Handle error
            }
        });

    }
}