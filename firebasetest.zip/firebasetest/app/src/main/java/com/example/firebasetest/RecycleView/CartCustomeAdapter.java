package com.example.firebasetest.RecycleView;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.firebasetest.R;

import java.util.ArrayList;

public class CartCustomeAdapter extends RecyclerView.Adapter<CartCustomeAdapter.MyViewHolder> {
    private ArrayList<DataModel> accountDataSet;
    private LayoutInflater inflater;
    private OnItemClickListener mListener;

    public interface OnItemClickListener {
        void onUpButtonClick(DataModel item);
        void onDownButtonClick(DataModel item);
    }

    public CartCustomeAdapter(Context context, ArrayList<DataModel> accountDataSet, OnItemClickListener listener) {
        this.accountDataSet = accountDataSet;
        this.inflater = LayoutInflater.from(context);
        this.mListener = listener;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.cart_cardrow, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        DataModel item = accountDataSet.get(position);
        holder.titleText.setText(item.getName());
        holder.amountText.setText(String.valueOf(item.getAmount()));
        holder.imageView.setImageResource(item.getImage());

        // Set click listeners for the buttons
        holder.increaseBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mListener != null) {
                    mListener.onUpButtonClick(item);
                }
            }
        });

        holder.decreaseBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mListener != null) {
                    mListener.onDownButtonClick(item);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return accountDataSet.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        TextView titleText;
        TextView amountText;
        ImageView imageView;
        Button increaseBtn;
        Button decreaseBtn;



        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            titleText = itemView.findViewById(R.id.titleText);
            amountText = itemView.findViewById(R.id.amountText);
            imageView = itemView.findViewById(R.id.imageView);
            increaseBtn = itemView.findViewById(R.id.upBtn);
            decreaseBtn = itemView.findViewById(R.id.downBtn);
        }
    }
}
