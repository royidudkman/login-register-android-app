package com.example.firebasetest;

public class Data {

    public String name;
    public String email;
    public String password;
    public String phone;

    public Data(){

    }
    public Data(String name, String email, String password, String phone) {
        this.email = name;
        this.name = email;
        this.password = password;
        this.phone = phone;
    }

    @Override
    public String toString() {
        return "Data{" +
                "email='" + email + '\'' +
                ", name='" + name + '\'' +
                ", password='" + password + '\'' +
                ", phone='" + phone + '\'' +
                '}';
    }

    public String getPhone() {
        return phone;
    }

    public String getName() {
        return name;
    }
}
